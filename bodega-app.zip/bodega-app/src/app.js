// ─── Estado global ────────────────────────────────────────────────────────────
const BODEGUEROS = [
  "Carlos Mendoza", "Luisa Pérez", "Roberto Gómez", "Ana Torres"
];

let registros = [];
let vista = "form"; // "form" | "lista"
let guardando = false;
let guardado = false;
let busqueda = "";
let detalleId = null;
let dataPath = "";

const formVacio = () => {
  const now = new Date();
  return {
    fechaEntrada: now.toISOString().split("T")[0],
    horaEntrada: now.toTimeString().slice(0, 5),
    horaIngreso: "",
    nombreConductor: "",
    telefonoConductor: "",
    placaVehiculo: "",
    nombreBodeguero: "",
    bodegueroCustom: "",
    facturas: [""],
    observaciones: "",
  };
};

let form = formVacio();

// ─── Inicialización ───────────────────────────────────────────────────────────
async function init() {
  // Cargar registros desde disco (%APPDATA%)
  registros = await window.bodegaAPI.leerRegistros();
  dataPath = await window.bodegaAPI.getDataPath();
  render();
}

// ─── Render principal ─────────────────────────────────────────────────────────
function render() {
  const app = document.getElementById("app");
  app.innerHTML = `
    ${renderHeader()}
    <div class="content fade-in">
      ${vista === "form" ? renderForm() : renderLista()}
    </div>
    ${renderFooter()}
    ${detalleId ? renderModal() : ""}
  `;
  bindEvents();
}

// ─── Header ───────────────────────────────────────────────────────────────────
function renderHeader() {
  return `
    <div class="header">
      <div class="logo">
        <div class="logo-icon">📦</div>
        <div>
          <div class="logo-title">BODEGA</div>
          <div class="logo-sub">REGISTRO DE ENTRADAS</div>
        </div>
      </div>
      <nav class="nav">
        <button class="tab ${vista === "form" ? "active" : ""}" data-tab="form">[ NUEVO ]</button>
        <button class="tab ${vista === "lista" ? "active" : ""}" data-tab="lista">
          [ REGISTROS ${registros.length > 0 ? `(${registros.length})` : ""} ]
        </button>
      </nav>
    </div>
  `;
}

// ─── Footer con ruta de datos ──────────────────────────────────────────────────
function renderFooter() {
  return `
    <div class="datapath-bar">
      <span>💾 Datos guardados en:</span>
      <span class="path">${dataPath || "cargando..."}</span>
    </div>
  `;
}

// ─── Formulario ───────────────────────────────────────────────────────────────
function renderForm() {
  if (guardado) {
    return `
      <div class="success-state">
        <div class="check-anim">✅</div>
        <div class="success-title">REGISTRO GUARDADO</div>
        <div class="success-sub">Preparando nuevo formulario...</div>
      </div>
    `;
  }

  const bodegueroOpts = BODEGUEROS.map(b =>
    `<option value="${b}" ${form.nombreBodeguero === b ? "selected" : ""}>${b}</option>`
  ).join("");

  const facturasHtml = form.facturas.map((f, i) => `
    <div class="factura-row">
      <div class="factura-num">${i + 1}</div>
      <input type="text" class="factura-input" data-idx="${i}" value="${f}" placeholder="Factura #${i + 1} — ej. F-001234" />
      ${form.facturas.length > 1 ? `<button class="btn-danger remove-factura" data-idx="${i}">✕</button>` : ""}
    </div>
  `).join("");

  const valido = esValido();

  return `
    <!-- 01 Fecha y hora -->
    <div class="section">
      <div class="section-label">01 — FECHA Y HORA <div class="section-line"></div></div>
      <div class="grid-3">
        <div class="campo-wrap">
          <label>FECHA DE ENTRADA *</label>
          <input type="date" id="fechaEntrada" value="${form.fechaEntrada}" />
        </div>
        <div class="campo-wrap">
          <label>HORA DE ENTRADA *</label>
          <input type="time" id="horaEntrada" value="${form.horaEntrada}" />
        </div>
        <div class="campo-wrap">
          <label>HORA DE INGRESO * <span class="note">(sistema)</span></label>
          <input type="time" id="horaIngreso" value="${form.horaIngreso}" />
        </div>
      </div>
    </div>

    <!-- 02 Conductor -->
    <div class="section">
      <div class="section-label">02 — DATOS DEL CONDUCTOR / REPARTIDOR <div class="section-line"></div></div>
      <div class="grid-2">
        <div class="campo-wrap">
          <label>NOMBRE COMPLETO *</label>
          <input type="text" id="nombreConductor" value="${form.nombreConductor}" placeholder="Ej. Juan García López" />
        </div>
        <div class="campo-wrap">
          <label>TELÉFONO</label>
          <input type="tel" id="telefonoConductor" value="${form.telefonoConductor}" placeholder="Ej. 8888-0000" />
        </div>
        <div class="campo-wrap col-full">
          <label>PLACA DEL VEHÍCULO</label>
          <input type="text" id="placaVehiculo" value="${form.placaVehiculo}" placeholder="Ej. A-12345" />
        </div>
      </div>
    </div>

    <!-- 03 Bodeguero -->
    <div class="section">
      <div class="section-label">03 — BODEGUERO RESPONSABLE <div class="section-line"></div></div>
      <div class="campo-wrap">
        <label>NOMBRE DEL BODEGUERO *</label>
        <select id="nombreBodeguero">
          <option value="">— Seleccionar bodeguero —</option>
          ${bodegueroOpts}
          <option value="__otro__" ${form.nombreBodeguero === "__otro__" ? "selected" : ""}>Otro...</option>
        </select>
        ${form.nombreBodeguero === "__otro__" ? `
          <input type="text" id="bodegueroCustom" value="${form.bodegueroCustom}" placeholder="Escribir nombre..." style="margin-top:8px;border-color:var(--verde);" />
        ` : ""}
      </div>
    </div>

    <!-- 04 Facturas -->
    <div class="section">
      <div class="section-label">04 — NÚMERO(S) DE FACTURA <div class="section-line"></div></div>
      ${facturasHtml}
      <button class="btn-secondary" id="addFactura" style="margin-top:4px;font-size:12px;">+ Agregar factura</button>
    </div>

    <!-- 05 Observaciones -->
    <div class="section">
      <div class="section-label">05 — OBSERVACIONES (OPCIONAL) <div class="section-line"></div></div>
      <div class="campo-wrap">
        <textarea id="observaciones" placeholder="Notas adicionales, condición del producto, incidencias...">${form.observaciones}</textarea>
      </div>
    </div>

    ${!valido ? `
      <div class="warn-box">
        ⚠ Campos requeridos: fecha, hora de entrada, hora de ingreso, conductor, bodeguero y al menos una factura.
      </div>
    ` : ""}

    <div class="form-actions">
      <button class="btn-primary" id="btnGuardar" ${valido ? "" : "disabled"}>▶ REGISTRAR ENTRADA</button>
    </div>
  `;
}

// ─── Lista de registros ───────────────────────────────────────────────────────
function renderLista() {
  const filtrados = registros.filter(r => {
    const q = busqueda.toLowerCase();
    return (
      r.nombreConductor?.toLowerCase().includes(q) ||
      r.nombreBodeguero?.toLowerCase().includes(q) ||
      r.bodegueroCustom?.toLowerCase().includes(q) ||
      r.facturas?.some(f => f.toLowerCase().includes(q)) ||
      r.placaVehiculo?.toLowerCase().includes(q)
    );
  });

  const cards = filtrados.length === 0
    ? `<div class="empty-state"><div class="icon">📭</div>${registros.length === 0 ? "No hay registros aún" : "Sin resultados para la búsqueda"}</div>`
    : filtrados.map(r => {
        const fecha = r.fechaEntrada ? r.fechaEntrada.split("-").reverse().join("/") : "—";
        const bodeguero = r.nombreBodeguero === "__otro__" ? r.bodegueroCustom : r.nombreBodeguero;
        const badges = (r.facturas || []).map(f => `<span class="badge">${f}</span>`).join("");
        return `
          <div class="registro-card" data-id="${r.id}">
            <div class="card-top">
              <div>
                <span class="card-conductor">${r.nombreConductor}</span>
                ${r.placaVehiculo ? `<span class="card-placa">${r.placaVehiculo}</span>` : ""}
              </div>
              <span class="card-fecha">${fecha}</span>
            </div>
            <div class="card-meta">
              Bodeguero: <span>${bodeguero}</span>
              &nbsp;·&nbsp; Entrada: <span>${r.horaEntrada || "—"}</span>
              &nbsp;·&nbsp; Ingreso: <span>${r.horaIngreso || "—"}</span>
            </div>
            <div>${badges}</div>
          </div>
        `;
      }).join("");

  return `
    <div class="search-bar">
      <input type="text" id="busqueda" value="${busqueda}" placeholder="🔍  Buscar por conductor, bodeguero, factura o placa..." />
      <span class="count-label">${filtrados.length} registros</span>
    </div>
    ${cards}
  `;
}

// ─── Modal detalle ────────────────────────────────────────────────────────────
function renderModal() {
  const r = registros.find(x => x.id === detalleId);
  if (!r) return "";
  const bodeguero = r.nombreBodeguero === "__otro__" ? r.bodegueroCustom : r.nombreBodeguero;
  const fecha = r.fechaEntrada ? r.fechaEntrada.split("-").reverse().join("/") : "—";

  const facturaRows = (r.facturas || []).map((f, i) => `
    <div style="color:var(--text);font-size:14px;padding:4px 0;border-bottom:1px solid var(--border);">
      <span style="color:var(--verde);margin-right:10px;">${i + 1}</span>${f}
    </div>
  `).join("");

  return `
    <div class="modal-bg" id="modalBg">
      <div class="modal fade-in">
        <div class="modal-header">
          <div class="modal-title">DETALLE DE REGISTRO</div>
          <button class="modal-close" id="cerrarModal">✕</button>
        </div>
        <div class="detail-row"><span class="detail-label">Fecha</span><span class="detail-value">${fecha}</span></div>
        <div class="detail-row"><span class="detail-label">Hora de entrada</span><span class="detail-value">${r.horaEntrada || "—"}</span></div>
        <div class="detail-row"><span class="detail-label">Hora de ingreso</span><span class="detail-value">${r.horaIngreso || "—"}</span></div>
        <div class="detail-divider"></div>
        <div class="detail-row"><span class="detail-label">Conductor</span><span class="detail-value">${r.nombreConductor}</span></div>
        <div class="detail-row"><span class="detail-label">Teléfono</span><span class="detail-value">${r.telefonoConductor || "—"}</span></div>
        <div class="detail-row"><span class="detail-label">Placa</span><span class="detail-value">${r.placaVehiculo || "—"}</span></div>
        <div class="detail-divider"></div>
        <div class="detail-row"><span class="detail-label">Bodeguero</span><span class="detail-value">${bodeguero}</span></div>
        <div class="detail-divider"></div>
        <div style="font-size:11px;color:var(--text-muted);letter-spacing:1px;margin-bottom:6px;">FACTURAS</div>
        ${facturaRows}
        ${r.observaciones ? `
          <div class="detail-divider"></div>
          <div style="font-size:11px;color:var(--text-muted);letter-spacing:1px;margin-bottom:6px;">OBSERVACIONES</div>
          <div style="font-size:13px;color:#aaa;line-height:1.6;">${r.observaciones}</div>
        ` : ""}
        <div style="margin-top:24px;display:flex;justify-content:flex-end;">
          <button class="btn-danger" id="btnEliminar">🗑 Eliminar registro</button>
        </div>
      </div>
    </div>
  `;
}

// ─── Bind de eventos ──────────────────────────────────────────────────────────
function bindEvents() {
  // Tabs
  document.querySelectorAll(".tab").forEach(btn => {
    btn.addEventListener("click", () => {
      vista = btn.dataset.tab;
      render();
    });
  });

  if (vista === "form" && !guardado) {
    // Campos del formulario
    ["fechaEntrada","horaEntrada","horaIngreso","nombreConductor","telefonoConductor","placaVehiculo","observaciones"].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.addEventListener("input", e => { form[id] = e.target.value; renderFormFields(); });
    });

    const selBodeguero = document.getElementById("nombreBodeguero");
    if (selBodeguero) {
      selBodeguero.addEventListener("change", e => {
        form.nombreBodeguero = e.target.value;
        renderFormFields();
      });
    }

    const inputCustom = document.getElementById("bodegueroCustom");
    if (inputCustom) {
      inputCustom.addEventListener("input", e => { form.bodegueroCustom = e.target.value; });
    }

    // Facturas
    document.querySelectorAll(".factura-input").forEach(el => {
      el.addEventListener("input", e => {
        const idx = parseInt(e.target.dataset.idx);
        form.facturas[idx] = e.target.value;
        updateSaveButton();
      });
    });

    document.querySelectorAll(".remove-factura").forEach(btn => {
      btn.addEventListener("click", e => {
        const idx = parseInt(e.target.dataset.idx);
        form.facturas.splice(idx, 1);
        render();
      });
    });

    const addBtn = document.getElementById("addFactura");
    if (addBtn) addBtn.addEventListener("click", () => { form.facturas.push(""); render(); });

    const guardarBtn = document.getElementById("btnGuardar");
    if (guardarBtn) guardarBtn.addEventListener("click", guardarRegistro);
  }

  if (vista === "lista") {
    const busqEl = document.getElementById("busqueda");
    if (busqEl) busqEl.addEventListener("input", e => { busqueda = e.target.value; render(); });

    document.querySelectorAll(".registro-card").forEach(card => {
      card.addEventListener("click", () => { detalleId = parseInt(card.dataset.id); render(); });
    });
  }

  // Modal
  const cerrar = document.getElementById("cerrarModal");
  if (cerrar) cerrar.addEventListener("click", () => { detalleId = null; render(); });

  const modalBg = document.getElementById("modalBg");
  if (modalBg) modalBg.addEventListener("click", e => { if (e.target === modalBg) { detalleId = null; render(); } });

  const eliminarBtn = document.getElementById("btnEliminar");
  if (eliminarBtn) eliminarBtn.addEventListener("click", async () => {
    registros = registros.filter(r => r.id !== detalleId);
    await window.bodegaAPI.guardarRegistros(registros);
    detalleId = null;
    render();
  });
}

// ─── Re-render parcial del formulario (para validación en tiempo real) ────────
function renderFormFields() {
  updateSaveButton();
  // Re-render solo si cambia visibilidad del campo custom
  const customWasVisible = !!document.getElementById("bodegueroCustom");
  const customShouldBeVisible = form.nombreBodeguero === "__otro__";
  if (customWasVisible !== customShouldBeVisible) render();
}

function updateSaveButton() {
  const btn = document.getElementById("btnGuardar");
  if (btn) btn.disabled = !esValido();
  const warn = document.querySelector(".warn-box");
  if (warn) warn.style.display = esValido() ? "none" : "block";
}

// ─── Validación ───────────────────────────────────────────────────────────────
function esValido() {
  return (
    form.fechaEntrada &&
    form.horaEntrada &&
    form.horaIngreso &&
    form.nombreConductor.trim() &&
    form.nombreBodeguero &&
    (form.nombreBodeguero !== "__otro__" || form.bodegueroCustom.trim()) &&
    form.facturas.some(f => f.trim())
  );
}

// ─── Guardar registro ─────────────────────────────────────────────────────────
async function guardarRegistro() {
  if (!esValido() || guardando) return;
  guardando = true;

  const nuevo = {
    ...form,
    facturas: form.facturas.filter(f => f.trim()),
    id: Date.now(),
    creadoEn: new Date().toISOString(),
  };

  registros.unshift(nuevo);
  await window.bodegaAPI.guardarRegistros(registros);

  guardado = true;
  guardando = false;
  render();

  setTimeout(() => {
    guardado = false;
    form = formVacio();
    render();
  }, 2000);
}

// ─── Arrancar ─────────────────────────────────────────────────────────────────
init();
