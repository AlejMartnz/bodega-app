const { contextBridge, ipcRenderer } = require("electron");

// Expone una API segura al renderer (la página HTML/JS)
// El renderer NO tiene acceso directo a Node — todo pasa por aquí
contextBridge.exposeInMainWorld("bodegaAPI", {
  leerRegistros: () => ipcRenderer.invoke("registros:leer"),
  guardarRegistros: (registros) => ipcRenderer.invoke("registros:guardar", registros),
  getDataPath: () => ipcRenderer.invoke("app:getDataPath"),
});
