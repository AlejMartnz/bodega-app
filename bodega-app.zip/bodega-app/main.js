const { app, BrowserWindow, ipcMain } = require("electron");
const path = require("path");
const fs = require("fs");

// ─── Ruta de datos en %APPDATA%\BodegaRegistro ───────────────────────────────
const DATA_DIR = path.join(app.getPath("userData"), "datos");
const DATA_FILE = path.join(DATA_DIR, "registros.json");

function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

function leerRegistros() {
  ensureDataDir();
  if (!fs.existsSync(DATA_FILE)) return [];
  try {
    const raw = fs.readFileSync(DATA_FILE, "utf-8");
    return JSON.parse(raw);
  } catch (e) {
    console.error("Error leyendo registros:", e);
    return [];
  }
}

function guardarRegistros(registros) {
  ensureDataDir();
  fs.writeFileSync(DATA_FILE, JSON.stringify(registros, null, 2), "utf-8");
}

// ─── Ventana principal ────────────────────────────────────────────────────────
let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 900,
    height: 700,
    minWidth: 700,
    minHeight: 550,
    title: "Bodega — Registro de Entradas",
    backgroundColor: "#0f1117",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
    },
    // Sin frame nativo para usar el header custom (opcional, ponlo en true si prefieres el título normal)
    frame: true,
    autoHideMenuBar: true,
  });

  mainWindow.loadFile("src/index.html");
}

app.whenReady().then(createWindow);

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});

app.on("activate", () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});

// ─── IPC: comunicación renderer ↔ main ───────────────────────────────────────
ipcMain.handle("registros:leer", () => {
  return leerRegistros();
});

ipcMain.handle("registros:guardar", (_event, registros) => {
  guardarRegistros(registros);
  return { ok: true };
});

ipcMain.handle("app:getDataPath", () => {
  return DATA_DIR;
});
