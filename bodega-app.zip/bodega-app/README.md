# 📦 Bodega — Registro de Entradas

App de escritorio (Windows) para registrar la entrada de productos en bodega.

## Requisitos

- [Node.js](https://nodejs.org) v18 o superior

## Instalación y uso

```bash
# 1. Instalar dependencias
npm install

# 2. Ejecutar en modo desarrollo
npm start
```

## Generar instalador (.exe)

```bash
# Instalador con wizard (recomendado)
npm run build

# Versión portable (sin instalación, solo .exe)
npm run build-portable
```

El instalador aparece en la carpeta `dist/`.

## Dónde se guardan los datos

Los registros se guardan automáticamente en:

```
%APPDATA%\BodegaRegistro\datos\registros.json
```

Por ejemplo en Windows 10/11:
```
C:\Users\TuUsuario\AppData\Roaming\BodegaRegistro\datos\registros.json
```

El archivo es JSON legible — puedes abrirlo con Notepad o Excel si necesitas hacer respaldos.

## Agregar/quitar bodegueros

Abre `src/app.js` y edita el arreglo al inicio del archivo:

```js
const BODEGUEROS = [
  "Carlos Mendoza",
  "Luisa Pérez",
  "Roberto Gómez",
  "Ana Torres"
];
```

## Estructura del proyecto

```
bodega-app/
├── main.js          ← Proceso principal de Electron (acceso al sistema)
├── preload.js       ← Puente seguro entre la UI y el sistema de archivos
├── package.json     ← Dependencias y configuración del build
├── assets/
│   └── icon.ico     ← Icono de la app (reemplazar con tu logo)
└── src/
    ├── index.html   ← Entrada HTML
    ├── styles.css   ← Estilos
    └── app.js       ← Lógica de la interfaz
```
